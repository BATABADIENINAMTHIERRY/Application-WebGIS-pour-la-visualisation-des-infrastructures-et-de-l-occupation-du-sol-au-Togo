const config = {
	extends: ['stylelint-config-standard', 'stylelint-prettier/recommended'],
	root: true,
};

export default config;
