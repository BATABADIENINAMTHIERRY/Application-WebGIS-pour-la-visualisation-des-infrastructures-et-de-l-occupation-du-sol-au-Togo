const config = {
	printWidth: 180,
	singleQuote: true,
	trailingComma: 'none',
	useTabs: true
};

export default config;
